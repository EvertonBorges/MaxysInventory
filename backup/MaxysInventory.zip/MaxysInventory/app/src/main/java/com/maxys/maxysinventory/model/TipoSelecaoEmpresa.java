package com.maxys.maxysinventory.model;

public enum TipoSelecaoEmpresa {
    CRUD, SELECAO
}
