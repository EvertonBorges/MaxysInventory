package com.maxys.maxysinventory.model;

public enum TipoRetornoIntent {
    BARCODE_SCAN, FILE_SEARCH
}
