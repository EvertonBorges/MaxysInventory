package com.maxys.maxysinventory.model;

public enum TipoTransicaoEmpresa {
    GERENCIAR_EMPRESA, GERENCIAR_PRODUTO, GERENCIAR_INVENTARIO
}
